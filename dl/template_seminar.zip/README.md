# LaTeX Vorlagen

| Vorlage        | PDF                                                                                    | ZIP                                                                                  |
| -------------- | :------------------------------------------------------------------------------------: | :----------------------------------------------------------------------------------: |
| Seminararbeit  | [Vorschau (PDF)](https://numpdes.github.io/thesis-template/pdfs/template_seminar.pdf)  | [Download (ZIP)](https://numpdes.github.io/thesis-template/dl/template_seminar.zip)  |
| Bachelorarbeit | [Vorschau (PDF)](https://numpdes.github.io/thesis-template/pdfs/template_bachelor.pdf) | [Download (ZIP)](https://numpdes.github.io/thesis-template/dl/template_bachelor.zip) |
| Masterarbeit   | [Vorschau (PDF)](https://numpdes.github.io/thesis-template/pdfs/template_diplom.pdf)   | [Download (ZIP)](https://numpdes.github.io/thesis-template/dl/template_diplom.zip)   |
| Dissertation   | [Vorschau (PDF)](https://numpdes.github.io/thesis-template/pdfs/template_diss.pdf)     | [Download (ZIP)](https://numpdes.github.io/thesis-template/dl/template_diss.zip)     |
